﻿namespace TNFAutoFoundation.Enums
{
    public enum Phasings
    {
        Construction,
        Design
    }
}