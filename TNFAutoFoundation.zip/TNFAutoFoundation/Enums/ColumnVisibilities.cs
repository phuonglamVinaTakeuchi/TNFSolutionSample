﻿namespace TNFAutoFoundation.Enums
{
    public enum ColumnVisibilities
    {
        ByX,
        ByY,
        SquareColumn
    }
}